import axios from 'axios';
import dotenv from 'dotenv';
import OpenAI from 'openai';
import fs from 'fs/promises';  // fs 모듈을 비동기적으로 가져옵니다.

dotenv.config();


export async function getNewsSentiment(symbol) {
    const API_URL = `https://www.alphavantage.co/query?function=NEWS_SENTIMENT&tickers=${symbol}`;
    const alphaApiKey = process.env.API_KEY;
    const url = `${API_URL}&apikey=${alphaApiKey}`;

    try {
        const response = await axios.get(url);

        // 응답 데이터에서 필요한 값 추출
        const { data } = response;

        // API 응답 구조에 맞게 feed 데이터 추출 (구조에 따라 수정 필요)
        if (data && data['feed']) {
            const limitedFeed = data['feed'].slice(0, 20);
            const sentimentData = limitedFeed.map(item => ({
                symbol: symbol['symbol'],
                title: item['title'],
                time_published: item['time_published'],
                summary: item['summary'],
                topics: item['topics'].map(topic => ({
                    topic: topic['topic'],
                    relevance_score: topic['relevance_score']
                })),
                overall_sentiment_score: item['overall_sentiment_score'],
                overall_sentiment_label: item['overall_sentiment_label'],
                ticker_sentiment: item['ticker_sentiment'].map(tickerData => ({
                    ticker: tickerData['ticker'],
                    relevance_score: tickerData['relevance_score'],
                    ticker_sentiment_score: tickerData['ticker_sentiment_score'],
                    ticker_sentiment_label: tickerData['ticker_sentiment_label']
                }))
            }));

            return sentimentData;
        } else {
            throw new Error('피드 데이터가 없습니다');
        }
    } catch (error) {
        if (error.response) {
            throw new Error(`Status: ${error.response.status}`);
        } else {
            throw new Error(`Error: ${error.message}`);
        }
    }
}


const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY, // 실제 API 키로 교체
});

export async function analyzeSentimentWithAI(sentimentData) {
    try {
        // JSON 파일 읽기
        const mainPrompt = await fs.readFile('prompt.json', 'utf8');

        const rolePrompt = `이 주식에 대한 감정 분석 데이터는 다음과 같습니다: ${JSON.stringify(sentimentData)}. 이 데이터를 토대로 주식에 대한 분석을 제공해주세요. 회사는 ${JSON.stringify(sentimentData[0].symbol)}입니다.` + mainPrompt;


        const completion = await openai.chat.completions.create({
            model: 'gpt-4o',
            messages: [{ role: 'system', content: rolePrompt }],
            max_tokens: 500,
        });

        return completion.choices[0].message.content;
    } catch (error) {
        console.error('Error reading prompt file or calling API:', error);
        throw new Error('처리 중 오류가 발생했습니다.');
    }
}
