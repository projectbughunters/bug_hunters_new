import OpenAI from 'openai';
import dotenv from 'dotenv';
import fs from 'fs';

dotenv.config();

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

// 공통 OpenAI 요청 함수
async function callOpenAI(systemMessage, userMessage) {
    try {
        const response = await openai.chat.completions.create({
            model: 'gpt-3.5-turbo',
            messages: [
                { role: 'system', content: systemMessage },
                { role: 'user', content: userMessage }
            ]
        });

        return response.choices[0].message.content;
    } catch (error) {
        console.error('OpenAI API 호출 오류:', error);
        throw new Error('OpenAI와의 통신 중 오류가 발생했습니다.');
    }
}

// 성장주 데이터 처리
export async function handleGrowth(stocks) {
    try {
        const requestData = JSON.parse(fs.readFileSync('growthrequest.json', 'utf8'));
        const stocksString = JSON.stringify(stocks, null, 2);

        return await callOpenAI(
            requestData.system,
            `다음은 성장주 데이터입니다:\n${stocksString}\n이 데이터를 기반으로 추천을 생성해주세요.`
        );
    } catch (error) {
        console.error('성장주 데이터 처리 오류:', error);
        throw error;
    }
}

// ESG 데이터 처리
export async function handleESG(stocks) {
    try {
        const requestData = JSON.parse(fs.readFileSync('esgrequest.json', 'utf8'));
        const stocksString = JSON.stringify(stocks, null, 2);

        return await callOpenAI(
            requestData.system,
            `다음은 ESG 주식 데이터입니다:\n${stocksString}\n이 데이터를 기반으로 추천을 생성해주세요.`
        );
    } catch (error) {
        console.error('ESG 데이터 처리 오류:', error);
        throw error;
    }
}

// 방어형 주식 데이터 처리
export async function handleDefensive(stocks) {
    try {
        const requestData = JSON.parse(fs.readFileSync('defensiverequest.json', 'utf8'));
        const stocksString = JSON.stringify(stocks, null, 2);

        return await callOpenAI(
            requestData.system,
            `다음은 방어형 주식 데이터입니다:\n${stocksString}\n이 데이터를 기반으로 추천을 생성해주세요.`
        );
    } catch (error) {
        console.error('방어형 주식 데이터 처리 오류:', error);
        throw error;
    }
}

// 기술주 주식 데이터 처리
export async function handleTech(stocks) {
    try {
        const requestData = JSON.parse(fs.readFileSync('techrequest.json', 'utf8'));
        const stocksString = JSON.stringify(stocks, null, 2);

        const systemMessageObject = requestData.messages.find(msg => msg.role === 'system');
        const systemMessage = systemMessageObject.content;

        return await callOpenAI(
            systemMessage,
            `다음은 기술주 주식 데이터입니다:\n${stocksString}\n이 데이터를 기반으로 추천을 생성해주세요.`
        );
    } catch (error) {
        console.error('기술주 주식 데이터 처리 오류:', error);
        throw error;
    }
}

// 가치주 주식 데이터 처리
export async function handleValue(stocks) {
    try {
        const requestData = JSON.parse(fs.readFileSync('valuerequest.json', 'utf8'));
        const stocksString = JSON.stringify(stocks, null, 2);


        return await callOpenAI(
            requestData.system,
            `다음은 가치주 주식 데이터입니다:\n${stocksString}\n이 데이터를 기반으로 추천을 생성해주세요.`
        );
    } catch (error) {
        console.error('가치주 주식 데이터 처리 오류:', error);
        throw error;
    }
}

// 배당주 주식 데이터 처리
export async function handleDividend(stocks) {
    try {
        const requestData = JSON.parse(fs.readFileSync('dividendrequest.json', 'utf8'));
        const stocksString = JSON.stringify(stocks, null, 2);

        return await callOpenAI(
            requestData.system,
            `다음은 배당주 주식 데이터입니다:\n${stocksString}\n이 데이터를 기반으로 추천을 생성해주세요.`
        );
    } catch (error) {
        console.error('배당주 주식 데이터 처리 오류:', error);
        throw error;
    }
}

