import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

// 환경변수 로드
const clientId = process.env.NAVER_CLIENT_ID;
const clientSecret = process.env.NAVER_CLIENT_SECRET;

export async function fetchCoinNews() {
    const naverUrl = "https://openapi.naver.com/v1/search/news.json";
    const params = {
      query: "코인",
      display: 50,
      start: 1,
      sort: "date",
    };
  
    try {
      const response = await axios.get(naverUrl, {
        params,
        headers: {
          "X-Naver-Client-Id": clientId,
          "X-Naver-Client-Secret": clientSecret,
        },
      });
      return response.data;
    } catch (error) {
      console.error("Error fetching Naver News:", error);
      throw new Error("Failed to fetch news from Naver API");
    }
  }

  export async function fetchCoinInfoNews(symbol) {
    const naverUrl = "https://openapi.naver.com/v1/search/news.json";
    const params = {
      query: symbol+"코인",
      display: 12,
      start: 1,
      sort: "date",
    };
  
    try {
      const response = await axios.get(naverUrl, {
        params,
        headers: {
          "X-Naver-Client-Id": clientId,
          "X-Naver-Client-Secret": clientSecret,
        },
      });
      return response.data;
    } catch (error) {
      console.error("Error fetching Naver News:", error);
      throw new Error("Failed to fetch news from Naver API");
    }
  }

  export async function fetchEconomyNews() {
    const naverUrl = "https://openapi.naver.com/v1/search/news.json";
    const params = {
      query: "경제",
      display: 50,
      start: 1,
      sort: "date",
    };
  
    try {
      const response = await axios.get(naverUrl, {
        params,
        headers: {
          "X-Naver-Client-Id": clientId,
          "X-Naver-Client-Secret": clientSecret,
        },
      });
      return response.data;
    } catch (error) {
      console.error("Error fetching Naver News:", error);
      throw new Error("Failed to fetch news from Naver API");
    }
  }

  export async function fetchStockNews() {
    const naverUrl = "https://openapi.naver.com/v1/search/news.json";
    const params = {
      query: "주식",
      display: 50,
      start: 1,
      sort: "date",
    };
  
    try {
      const response = await axios.get(naverUrl, {
        params,
        headers: {
          "X-Naver-Client-Id": clientId,
          "X-Naver-Client-Secret": clientSecret,
        },
      });
      return response.data;
    } catch (error) {
      console.error("Error fetching Naver News:", error);
      throw new Error("Failed to fetch news from Naver API");
    }
  }

  export async function fetchStockInfoNews(symbol) {
    const naverUrl = "https://openapi.naver.com/v1/search/news.json";
    const params = {
      query: symbol+"주식",
      display: 12,
      start: 1,
      sort: "date",
    };
  
    try {
      const response = await axios.get(naverUrl, {
        params,
        headers: {
          "X-Naver-Client-Id": clientId,
          "X-Naver-Client-Secret": clientSecret,
        },
      });
      return response.data;
    } catch (error) {
      console.error("Error fetching Naver News:", error);
      throw new Error("Failed to fetch news from Naver API");
    }
  }

 