import oracledb from "oracledb";
import nodemailer from "nodemailer";
import bcrypt from "bcrypt";

// Oracle DB 연결 정보
const dbConfig = {
  user: "bughunters",
  password: "12345",
  connectString: "localhost/xe", // 예: localhost로 연결
};

//보내는사람 메일 주소 설정
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'kimee0612@gmail.com',
    pass: 'bpnp aplm zcpc csvz',
  }
});

// 임시 비밀번호 생성 함수
function generateTemporaryPassword() {
  const charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let tempPassword = "";
  for (let i = 0; i < 8; i++) { // 비밀번호 길이: 8자
    const randomIndex = Math.floor(Math.random() * charset.length);
    tempPassword += charset[randomIndex];
  }
  return tempPassword;
}

//비밀번호 인코딩 함수 (bcrypt 사용)
async function hashPassword(password) {
  const saltRounds = 10; // 해싱 반복 횟수
  const hashedPassword = await bcrypt.hash(password, saltRounds);
  return hashedPassword;
}

async function verifyPassword(inputPassword, hashedPassword) {
  const isMatch = await bcrypt.compare(inputPassword, hashedPassword);
  return isMatch;
}

/*
// 비밀번호 검증  예제 실행
(async () => {
  const inputPassword = "사용자_입력_비밀번호";
  const hashedPassword = "해싱된_비밀번호";

  const isValid = await verifyPassword(inputPassword, hashedPassword);
  if (isValid) {
    console.log("비밀번호가 일치합니다.");
  } else {
    console.log("비밀번호가 일치하지 않습니다.");
  }
})();
*/

export async function findPassword(member_id, res) {
  
  try {
    // 오라클 DB 연결
    let connection = await oracledb.getConnection(dbConfig);

    //console.log('실행된 쿼리:', `SELECT email, password FROM member WHERE member_id = (:member_id)`);
    //console.log('바인딩 변수:', [member_id]);

    // member_id로 이메일과 비밀번호 조회(검증완료 된 member_id)
    const result = await connection.execute(
      `SELECT email FROM member WHERE member_id = (:member_id)`,
      [member_id]
    );

    //console.log('비밀번호 ', result);

    const email = result.rows[0][0]; // 이메일 인덱스 수정
    const tempPassword = generateTemporaryPassword();

    console.log("생성된 임시 비밀번호 : ", tempPassword);

    // 임시 비밀번호 해싱
    const hashedPassword = await bcrypt.hash(tempPassword, 10);

    // DB에 해싱된 비밀번호 저장
    await connection.execute(
        `UPDATE member SET password = :password WHERE member_id = :member_id`,
        [hashedPassword, member_id],
        { autoCommit: true }
    );

    // Nodemailer로 비밀번호 이메일 발송
    const mailOptions = {
        from: "kimee0612@gmail.com",
        to: email,
        subject: 'TMI) 임시 비밀번호 발송 메일입니다.',
        text: `요청하신 임시비밀번호는 ${tempPassword} 입니다. 로그인 후 반드시 비밀번호를 변경해 주세요.`
    };

      /*서버연결 성공여부 확인
                transporter.verify((error, success) => {
                  if (error) {
                    console.error("SMTP 연결 실패:", error);
                  } else {
                    console.log("SMTP 서버 연결 성공!");
                  }
                });
         */

      transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
          console.log("Email 발송 오류 : ",error);
          return res.status(500).send('이메일 발송에 실패했습니다.');
        }
        res.status(200).send('임시 비밀번호가 이메일로 발송되었습니다.');
      });
    
    // DB 연결 종료
    await connection.close();

  } catch (err) {
    console.error(err);
    res.status(500).send('서버 오류가 발생했습니다.');
  }
}






