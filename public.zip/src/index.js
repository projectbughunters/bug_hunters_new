import express from "express"; //반드시 첫줄에 적용
import dotenv from "dotenv";
import cors from "cors";
import mongoose from "mongoose";
import bodyParser from "body-parser";
import { fetchTopStocks, stockInfoData, overviewStockData, overviewStock } from './stocksever.js';
import { fetchcoinData, chartcoinData, getCoinInfoByTicker, fetchDominance } from "./coinsever.js";
import { getCommoditiesData1, getCommoditiesData2 } from "./economyserver.js";
import { findPassword } from "./userserver.js";
import { fetchCoinNews, fetchEconomyNews, fetchStockNews, fetchStockInfoNews, fetchCoinInfoNews } from "./newsserver.js";
import {getNewsSentiment, analyzeSentimentWithAI} from './newsSentiment.js';   
import { calculateExchangeRate, alphavantageExchangeRate } from "./exchange.js";
import { handleGrowth, handleESG, handleDefensive, handleTech, handleValue, handleDividend} from './stockhandlers.js';


// Express 앱 설정
const app = express();
const port = 3000;
app.use(cors());
app.use(express.json()); 
dotenv.config();
app.use(bodyParser.json());



// MongoDB 연결
mongoose
  .connect("mongodb://127.0.0.1:27017/bughuntersdb", { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB 연결 성공"))
  .catch((err) => console.error("MongoDB 연결 실패:", err));

  //stock====================================================
  // API 엔드포인트
  app.post("/top-stocks", async (req, res) => {
    try {
      const data = await fetchTopStocks();
      
      res.json(data);
    } catch (err) {
      res.status(500).send("주식 데이터 가져오기 실패");
    }
  });
  
  app.get("/stock-info", async (req, res) => {
    try {
      const symbol = req.query.symbol; // URL 쿼리 파라미터에서 coin 추출
      const timeframe = req.query.timeframe;
      if (!symbol) {
        return res.status(400).send("symbol is required");
      }
  
      const dailyData=await stockInfoData(symbol,timeframe); // API 호출 및 데이터 저장
      //const stocks = await Stock.find(); // MongoDB에서 데이터 조회
      res.json(dailyData); // JSON 형식으로 응답
    } catch (err) {
      console.error(err);
      res.status(500).send("데이터 조회 실패");
    }
  });
  
  app.post("/stock-overview", async (req, res) => {
    try {
      const {symbol}= req.body; // URL 쿼리 파라미터에서 keyword 추출
      if (!symbol) {
        return res.status(400).send("symbol is required");
      }
  
      const overviewData=await overviewStockData(symbol); // API 호출 및 데이터 저장
      //const stocks = await Stock.find(); // MongoDB에서 데이터 조회
      res.json(overviewData); // JSON 형식으로 응답
    } catch (err) {
      console.error(err);
      res.status(500).send("데이터 조회 실패");
    }
  });

  app.post("/stock-data", async (req, res) => {
    try {
      const {symbol}= req.body; // URL 쿼리 파라미터에서 keyword 추출
      if (!symbol) {
        return res.status(400).send("symbol is required");
      }
  
      const overviewData=await overviewStock(symbol); // API 호출 및 데이터 저장
      //const stocks = await Stock.find(); // MongoDB에서 데이터 조회
      res.json(overviewData); // JSON 형식으로 응답
    } catch (err) {
      console.error(err);
      res.status(500).send("데이터 조회 실패");
    }
  });

  app.get("/stock-ov", async (req, res) => {
    try {
      const symbol = req.query.symbol;  // URL 쿼리 파라미터에서 keyword 추출
      if (!symbol) {
        return res.status(400).send("symbol is required");
      }
  
      const overviewData=await overviewStock(symbol); // API 호출 및 데이터 저장
      //const stocks = await Stock.find(); // MongoDB에서 데이터 조회
      res.json(overviewData); // JSON 형식으로 응답
    } catch (err) {
      console.error(err);
      res.status(500).send("데이터 조회 실패");
    }
  });

  // coin============================================================
  // 웹 페이지 요청 시 MongoDB에서 데이터 조회 후 HTML로 반환
app.get("/content", async (req, res) => {
  try {
      const coins = await fetchcoinData(); 
      res.json(coins); 
  } catch (err) {
      res.status(500).send("데이터 조회 실패");
  }
});

app.get("/getCoinInfo", async (req, res) => {
  const ticker = req.query.symbol;
  if (!ticker) {
    return res.status(400).send("티커 정보가 필요합니다.");
  }
  try {
    const coinInfo = await getCoinInfoByTicker(ticker); 
    res.json(coinInfo); 
  } catch (err) {
    res.status(500).send("데이터 조회 실패: " + err.message);
  }
});

// /coin 경로에서 Alpha Vantage API에서 데이터를 가져옴
app.get("/coin", async (req, res) => {
  try {
      const symbol = req.query.symbol; // URL 쿼리 파라미터에서 coin 추출
      const timeframe = req.query.timeframe;
      if (!symbol) {
          return res.status(400).send("symbol 파라미터가 필요합니다.");
      }
      

      const coinData = await chartcoinData(symbol,timeframe); // API 호출 및 데이터 가져오기
      res.json(coinData); // JSON 형식으로 응답
  } catch (err) {
      console.error(err);
      res.status(500).send("데이터 조회 실패");
  }
});

app.get("/dominance", async (req, res) => {
  try {
      const dominance = await fetchDominance();
      if (!dominance) {
          return res.status(500).send("시장 점유율 데이터를 가져올 수 없습니다.");
      }
      res.json(dominance);
  } catch (err) {
      res.status(500).send("데이터 조회 실패");
  }
});

//economy===============================================================
app.get('/commodities', async (req, res) => {
  const symbol = req.query.symbol; // 쿼리 문자열에서 symbol 가져오기
  const timeframe = req.query.timeframe; // 쿼리 문자열에서 timeframe 가져오기

  try {
      if(timeframe==='monthly' || timeframe === 'weekly' || timeframe === 'daily') {
          const commoditiesData = await getCommoditiesData1(symbol, timeframe); // 키워드, 타임프레임을 인자로 전달
          res.json(commoditiesData); // 클라이언트에게 JSON 형태로 데이터 전송
      }else if(timeframe==='quarterly' || timeframe === 'annual') {
          const commoditiesData = await getCommoditiesData2(symbol, timeframe); // 키워드, 타임프레임을 인자로 전달
          res.json(commoditiesData); // 클라이언트에게 JSON 형태로 데이터 전송
      }
  } catch (error) {
      res.status(500).send(error.message); // 오류 발생 시 500 상태 코드와 메시지 전송
  }
});


//news==================================================================
app.post("/coinnews", async (req, res) => {
  try {
    // 네이버 뉴스 데이터 가져오기
    const newsData = await fetchCoinNews();  

    // 클라이언트에 응답
    res.json(newsData);
  } catch (error) {
    console.error("Error handling /news/newsMain:", error);
    res.status(500).json({ error: error.message });
  }
});

app.post("/coininfonews", async (req, res) => {
  try {
    // 네이버 뉴스 데이터 가져오기
    const symbol = req.body.symbol
    const newsData = await fetchCoinInfoNews(symbol);  

    // 클라이언트에 응답
    res.json(newsData);
  } catch (error) {
    console.error("Error handling /news/newsMain:", error);
    res.status(500).json({ error: error.message });
  }
});

app.post("/economynews", async (req, res) => {
  try {
    // 네이버 뉴스 데이터 가져오기
    const newsData = await fetchEconomyNews();  

    // 클라이언트에 응답
    res.json(newsData);
  } catch (error) {
    console.error("Error handling /news/newsMain:", error);
    res.status(500).json({ error: error.message });
  }
});

app.post("/stocknews", async (req, res) => {
  try {
    // 네이버 뉴스 데이터 가져오기
    const newsData = await fetchStockNews();  

    // 클라이언트에 응답
    res.json(newsData);
  } catch (error) {
    console.error("Error handling /news/newsMain:", error);
    res.status(500).json({ error: error.message });
  }
});

app.post("/stockinfonews", async (req, res) => {
  try {
    // 네이버 뉴스 데이터 가져오기
    const symbol = req.body.symbol
    const newsData = await fetchStockInfoNews(symbol);  

    // 클라이언트에 응답
    res.json(newsData);
  } catch (error) {
    console.error("Error handling /news/newsMain:", error);
    res.status(500).json({ error: error.message });
  }
});

//user=============================================================
app.get('/findPassword', async (req, res) => {
  const { member_id } = req.query; // 클라이언트에서 member_id를 수신

  await findPassword(member_id,res);
});

//=================감정분석==============================
app.post('/stock/aiChatbot', async (req, res) => {
  
  try {
    // 감정 분석 데이터 가져오기
    const symbol = req.body.sentimentData;
    const sentimentData = await getNewsSentiment(symbol);
    console.log("Received sentiment data:", sentimentData);
    // AI 분석 요청
    const reply = await analyzeSentimentWithAI(sentimentData);
    console.log(reply)

    // AI 응답 전달
    res.json({ reply: reply });
} catch (error) {
    console.error('오류 발생:', error);
    res.status(500).json({ error: 'OpenAI와의 통신 중 오류가 발생했습니다.' });
}
});


  // 서버 시작
  app.listen(port, () => {
    console.log(`Node.js service listening at http://localhost:${port}`);
});

//AiChatBot=======================================================

//Ai추천=======================================================
// POST 엔드포인트: /aiRecommend
app.post('/aiRecommend', async (req, res) => {
  const {theme, stocks} = req.body;

  try {
      let result;

      // 테마에 따라 적절한 메서드 호출
      switch (theme) {
          case 'Growth':
              result = await handleGrowth(stocks);
              break;
          case 'ESG':
              result = await handleESG(stocks);
              break;
          case 'Defensive':
              result = await handleDefensive(stocks);
              break;
          case 'Tech':
              result = await handleTech(stocks);
              break;
          case 'Value':
              result = await handleValue(stocks);
              break;
          case 'Dividend':
              result = await handleDividend(stocks);
              break;
          default:
              throw new Error(`알 수 없는 테마: ${theme}`);
      }

      res.status(200).json({message: `${theme} 추천 생성 완료`, result });
  } catch (error) {
      console.error(`${theme} 추천 생성 중 오류 발생:`, error);
      res.status(500).json({ error: `${theme} 추천 생성 중 오류가 발생했습니다.` });
  }
});

//exchange=========================================================
app.post('/currency', async (req, res) => {
  try {
      const { amount, fromCurrency, toCurrency } = req.body;

      // 요청 본문에 필수 값이 모두 있는지 확인
      if (!amount || !fromCurrency || !toCurrency) {
          return res.status(400).json({ error: '필수 파라미터가 누락되었습니다.' });
      }

      // 환율 계산
      const convertedAmount = await alphavantageExchangeRate(fromCurrency, toCurrency, amount);

      if (!convertedAmount) {
          return res.status(500).json({ error: '환율 계산에 실패했습니다.' });
      }

      res.status(200).json({ convertedAmount });
  } catch (error) {
      console.error('서버 오류:', error);
      res.status(500).json({ error: '서버 오류가 발생했습니다.' });
  }
});
