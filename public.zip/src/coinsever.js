import axios from "axios";
import dotenv from "dotenv";

dotenv.config();


// 암호화폐 API에서 데이터 가져오기
export async function fetchcoinData() {
    try {
        const response = await axios.get("https://api.coinpaprika.com/v1/tickers?quotes=USD");
        const coins = response.data.slice(0, 100);
        
        const coinData = coins.map(coin => ({
            symbol: coin.symbol,
            name: coin.name,
            rank: coin.rank,
            date: new Date().toISOString(),
            quotes: {
                USD: {
                    price: coin.quotes.USD.price,
                    market_cap: coin.quotes.USD.market_cap,
                    volume_24h: coin.quotes.USD.volume_24h,
                    percent_change_24h: coin.quotes.USD.percent_change_24h,
                    percent_change_7d: coin.quotes.USD.percent_change_7d,
                    total_supply: coin.total_supply,
                    max_supply: coin.max_supply,
                    ath_price: coin.quotes.USD.ath_price,
                    ath_date: coin.quotes.USD.ath_date,
                    percent_from_price_ath: coin.quotes.USD.percent_from_price_ath,
                    market_cap_change_24h: coin.quotes.USD.market_cap_change_24h,
                    percent_change_24h: coin.quotes.USD.percent_change_24h
                }
            }
        }));

       
        return coinData;
    } catch (err) {
        console.error("암호화폐 데이터 가져오기 오류:", err);
    }
}

export async function getCoinInfoByTicker(ticker) {
    if (!ticker) {
      throw new Error("티커 정보가 제공되지 않았습니다.");
    }
    try {
      // 전체 코인 목록을 가져옵니다.
      const response = await axios.get("https://api.coinpaprika.com/v1/tickers?quotes=USD");
      const coins = response.data;  // slice 제거
      // 입력된 티커와 일치하는 코인을 대소문자 구분 없이 찾습니다.
      const coin = coins.find(c => c.symbol.toUpperCase() === ticker.toUpperCase());
      if (!coin) {
        throw new Error(`티커 ${ticker}에 해당하는 암호화폐를 찾을 수 없습니다.`);
      }
      // 필요한 정보만 객체로 반환합니다.
      return {
        symbol: coin.symbol,
        name: coin.name,
        rank: coin.rank,
        price: coin.quotes.USD.price,
        market_cap: coin.quotes.USD.market_cap,
        volume_24h: coin.quotes.USD.volume_24h,
        percent_change_24h: coin.quotes.USD.percent_change_24h,
        percent_change_7d: coin.quotes.USD.percent_change_7d
      };
    } catch (error) {
      throw new Error('정보를 가져오는 중 오류가 발생했습니다: ' + error.message);
    }
  }

// 암호화폐 API에서 데이터 가져오기
export async function chartcoinData(symbol,timeframe) {
    try {
        const apiKey = process.env.API_KEY; // 환경 변수에서 API 키 가져오기
        const market = process.env.MARKET;
        const response = await axios.get( 
            "https://www.alphavantage.co/query", // URL을 문자열로 수정
            {
                params: {
                    function: "DIGITAL_CURRENCY_"+timeframe,
                    symbol: symbol,
                    market: market,
                    apikey: apiKey,
                },
            }
        );
        //console.log("API 응답 데이터:", response.data);

        let dailyData; // dailyData 변수 선언
  
      if (timeframe === "DAILY") {
        dailyData = response.data["Time Series (Digital Currency Daily)"];
      } else if (timeframe === "WEEKLY") {
        dailyData = response.data["Time Series (Digital Currency Weekly)"];
      } else if (timeframe === "MONTHLY") {
        dailyData = response.data["Time Series (Digital Currency Monthly)"];
      }
  
      
        if (!dailyData) {
            throw new Error("API 데이터가 없습니다.");
        }

        const processedData = [];

        // 데이터를 배열에 추가하고, 최신 데이터가 오른쪽에 나오도록 처리
        for (const [date, values] of Object.entries(dailyData)) {
            const coinData = {
                symbol,
                date,
                open: parseFloat(values["1. open"]),
                high: parseFloat(values["2. high"]),
                low: parseFloat(values["3. low"]),
                close: parseFloat(values["4. close"]),
                volume: parseInt(values["5. volume"], 10),
            };

            processedData.push(coinData);
        }

        // 데이터를 날짜 순서대로 내림차순 정렬 (최신 날짜가 오른쪽에 오도록)
        return processedData.reverse();

    } catch (err) {
        console.error("암호화폐 데이터 가져오기 오류:", err);
        return [];
    }
}

export async function fetchDominance() {
  try {
      const response = await axios.get("https://api.coingecko.com/api/v3/global");
      const dominance = response.data.data.market_cap_percentage;
      
      return dominance;
  } catch (error) {
      console.error("Error fetching data:", error);
      return null;
  }
}







