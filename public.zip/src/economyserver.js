import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config(); // .env 파일의 환경 변수 로드

const getCommoditiesData1 = (symbol, timeframe) => {
    const apiKey = process.env.API_KEY; // .env에서 API 키 가져오기
    const url = `https://www.alphavantage.co/query?function=${symbol}&interval=${timeframe}&apikey=${apiKey}`; // symbol을 사용

    return new Promise((resolve, reject) => {
        axios.get(url)
            .then(response => {
                resolve(response.data); // JSON 데이터 반환
            })
            .catch(error => {
                reject(new Error('데이터를 가져오는 데 실패했습니다.')); // 오류 메시지
            });
    });
};

const getCommoditiesData2 = (symbol, timeframe) => {
    const apiKey = process.env.API_KEY; // .env에서 API 키 가져오기
    const url = `https://www.alphavantage.co/query?function=${symbol}&interval=${timeframe}&apikey=${apiKey}`; // symbol을 사용

    return new Promise((resolve, reject) => {
        axios.get(url)
            .then(response => {
                resolve(response.data); // JSON 데이터 반환
            })
            .catch(error => {
                reject(new Error('데이터를 가져오는 데 실패했습니다.')); // 오류 메시지
            });
    });
};


// 두 함수 모두 내보내기
export { getCommoditiesData1, getCommoditiesData2 };
