import axios from 'axios';
import dotenv from 'dotenv';

// .env 파일에서 환경 변수 불러오기
dotenv.config();

const EXCHANGE_RATE_KEY = process.env.EXCHANGE_RATE_KEY;
const API_KEY = process.env.API_KEY;

export async function calculateExchangeRate(fromCurrency, toCurrency, amount) {
    try {
        // 환율 API 요청
        const response = await axios.get(`https://v6.exchangerate-api.com/v6/${EXCHANGE_RATE_KEY}/latest/USD`);

        // 응답에서 환율 정보 가져오기
        if (response.data && response.data.conversion_rates && response.data.conversion_rates[fromCurrency] && response.data.conversion_rates[toCurrency]) {
            const rateFrom = response.data.conversion_rates[fromCurrency]; // 원화에 대한 환율
            const rateTo = response.data.conversion_rates[toCurrency]; // 대상 통화에 대한 환율
            
            // USD -> KRW 환율 계산 (원화 -> 대상 통화)
            const convertedAmount = (amount / rateFrom) * rateTo; // USD -> KRW 계산
            return convertedAmount.toFixed(2);
        } else {
            throw new Error(`환율 정보를 찾을 수 없습니다: ${fromCurrency} -> ${toCurrency}`);
        }
    } catch (error) {
        console.error('환율 API 호출 오류:', error.response ? error.response.data : error.message);
        throw new Error('환율 계산 중 오류가 발생했습니다.');
    }
}

export async function alphavantageExchangeRate(fromCurrency, toCurrency, amount) {
    try {
        // Alpha Vantage 환율 API 요청
        const url = `https://www.alphavantage.co/query?function=CURRENCY_EXCHANGE_RATE&from_currency=${fromCurrency}&to_currency=${toCurrency}&apikey=${API_KEY}`;
        const response = await axios.get(url);

        // 응답에서 환율 정보 가져오기
        const exchangeRateData = response.data['Realtime Currency Exchange Rate'];
        if (exchangeRateData && exchangeRateData['5. Exchange Rate']) {
            const exchangeRate = parseFloat(exchangeRateData['5. Exchange Rate']); // 환율 값
            if (!isNaN(exchangeRate)) {
                // 환율을 적용하여 금액 변환
                const convertedAmount = amount * exchangeRate;
                return convertedAmount.toFixed(2);
            } else {
                throw new Error('유효하지 않은 환율 데이터입니다.');
            }
        } else {
            throw new Error('환율 정보를 찾을 수 없습니다.');
        }
    } catch (error) {
        console.error('Alpha Vantage API 호출 오류:', error.response ? error.response.data : error.message);
        throw new Error('환율 계산 중 오류가 발생했습니다.');
    }
}