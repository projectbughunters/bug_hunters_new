import mongoose from "mongoose";
import axios from "axios";
import dotenv from "dotenv";
import yahooFinance from "yahoo-finance2";

dotenv.config();

// 주식 데이터 스키마 정의
const stockSchema = new mongoose.Schema({
  symbol: { type: String, required: true }, // 주식 티커
  name: { type: String, required: true },
  date: { type: String, required: true },
  type: String,
  region: String,
  currency: String,
  marketPrice: Number,
  marketChange: Number,
  marketCap: String,
});

const Stock = mongoose.model("Stock", stockSchema);

// MongoDB 스키마 정의
const stockOverviewSchema = new mongoose.Schema({
  date: { type: String, required: true },
  symbol: { type: String, required: true },
  assetType: { type: String, default: "Unknown" },
  name: { type: String, default: "N/A" },
  description: { type: String, default: "N/A" },
  cik: { type: String, default: "N/A" },
  exchange: { type: String, default: "Unknown" },
  currency: { type: String, default: "USD" },
  country: { type: String, default: "Unknown" },
  sector: { type: String, default: "Unknown" },
  industry: { type: String, default: "Unknown" },
  address: { type: String, default: "N/A" },
  officialSite: { type: String, default: "N/A" },
  fiscalYearEnd: { type: String, default: "N/A" },
  latestQuarter: { type: String, default: "N/A" },
  marketCapitalization: { type: String, default: "N/A" },
  ebitda: { type: String, default: "N/A" },
  peRatio: { type: String, default: "N/A" },
  pegRatio: { type: String, default: "N/A" },
  bookValue: { type: String, default: "N/A" },
  dividendPerShare: { type: String, default: "N/A" },
  dividendYield: { type: String, default: "N/A" },
  eps: { type: String, default: "N/A" },
  revenuePerShareTTM: { type: String, default: "N/A" },
  profitMargin: { type: String, default: "N/A" },
  operatingMarginTTM: { type: String, default: "N/A" },
  returnOnAssetsTTM: { type: String, default: "N/A" },
  returnOnEquityTTM: { type: String, default: "N/A" },
  revenueTTM: { type: String, default: "N/A" },
  grossProfitTTM: { type: String, default: "N/A" },
  dilutedEPSTTM: { type: String, default: "N/A" },
  quarterlyEarningsGrowthYOY: { type: String, default: "N/A" },
  quarterlyRevenueGrowthYOY: { type: String, default: "N/A" },
  analystTargetPrice: { type: String, default: "N/A" },
  analystRatingStrongBuy: { type: String, default: "N/A" },
  analystRatingBuy: { type: String, default: "N/A" },
  analystRatingHold: { type: String, default: "N/A" },
  analystRatingSell: { type: String, default: "N/A" },
  analystRatingStrongSell: { type: String, default: "N/A" },
  trailingPE: { type: String, default: "N/A" },
  forwardPE: { type: String, default: "N/A" },
  priceToSalesRatioTTM: { type: String, default: "N/A" },
  priceToBookRatio: { type: String, default: "N/A" },
  evToRevenue: { type: String, default: "N/A" },
  evToEBITDA: { type: String, default: "N/A" },
  beta: { type: String, default: "N/A" },
  fiftyTwoWeekHigh: { type: String, default: "N/A" },
  fiftyTwoWeekLow: { type: String, default: "N/A" },
  fiftyDayMovingAverage: { type: String, default: "N/A" },
  twoHundredDayMovingAverage: { type: String, default: "N/A" },
  sharesOutstanding: { type: String, default: "N/A" },
  dividendDate: { type: String, default: "N/A" },
  exDividendDate: { type: String, default: "N/A" },
}, { timestamps: true }); 

const overView = mongoose.model("overView", stockOverviewSchema);

const additionalSymbols = JSON.parse(process.env.ADDITIONAL_SYMBOLS);

// 마지막 저장 날짜를 기록할 변수
let lastSavedDate = null;

// 암호화폐 데이터 저장 함수
async function savestockData(stockData) {
    try {
        for (const stock of stockData) {
            const newStock = new Stock(stock);
            await newStock.save();
        }
        // 마지막 저장 날짜 업데이트
        lastSavedDate = new Date().toISOString().split('T')[0]; // YYYY-MM-DD 형식
    } catch (err) {
        console.error("암호화폐 데이터 저장 오류:", err);
    }
}
  
// 상위 주식 데이터를 가져오고 가공하는 통합 함수
export async function fetchTopStocks() {
  try {
    // 상위 심볼 목록 선택 (최대 95개)
    const topSymbols = [...additionalSymbols].slice(0, 95);

    // 각 심볼에 대해 Yahoo Finance API 호출 한 번으로 필요한 정보 모두 가공
    const stockDataPromises = topSymbols.map(async (symbol) => {
      try {
        const details = await yahooFinance.quote(symbol);
        return {
          symbol: details.symbol,
          name: details.shortName || "N/A",
          type: details.quoteType || "Unknown",
          region: details.market || "Unknown",
          currency: details.currency || "USD",
          trailingPE: details.trailingPE,
          date: new Date().toISOString(), // 데이터 조회 시각
          marketPrice: details.regularMarketPrice,
          marketChange: details.regularMarketChangePercent,
          marketCap: details.marketCap
        };
      } catch (error) {
        console.error(`Error processing symbol ${symbol}:`, error);
        return null; // 오류 발생 시 null 처리
      }
    });

    // 모든 데이터를 병렬로 가져온 후, null 값 제거 및 marketCap 기준 내림차순 정렬
    const stockData = await Promise.all(stockDataPromises);
    return stockData
      .filter((data) => data !== null)
      .sort((a, b) => b.marketCap - a.marketCap);
  } catch (err) {
    console.error("주식 데이터 가져오기 실패:", err);
    throw err;
  }
}


  // 주식 API에서 데이터 가져오기
  export async function stockInfoData(symbol, timeframe) {
    try {
      const apiKey = process.env.API_KEY;
      const response = await axios.get(
        "https://www.alphavantage.co/query",  // URL을 문자열로 감싸기
        {
          params: {
            function: "TIME_SERIES_" + timeframe,
            symbol: symbol,
            apikey: apiKey,
          },
        }
      );
  
      let dailyData; // dailyData 변수 선언
  
      if (timeframe === "DAILY") {
        dailyData = response.data["Time Series (Daily)"];
      } else if (timeframe === "WEEKLY") {
        dailyData = response.data["Weekly Time Series"];
      } else if (timeframe === "MONTHLY") {
        dailyData = response.data["Monthly Time Series"];
      }
  
      if (!dailyData) {
        throw new Error("API 데이터가 없습니다.");
      }
  
      const processedData = [];
  
      // 데이터를 배열에 추가하고, 최신 데이터가 오른쪽에 나오도록 처리
      for (const [date, values] of Object.entries(dailyData)) {
        const stockData = {
          symbol, // symbol 추가
          date,
          open: parseFloat(values["1. open"]),
          high: parseFloat(values["2. high"]),
          low: parseFloat(values["3. low"]),
          close: parseFloat(values["4. close"]),
          volume: parseInt(values["5. volume"], 10),
        };
  
        processedData.push(stockData);
      }
  
      // 데이터를 날짜 순서대로 내림차순 정렬 (최신 날짜가 오른쪽에 오도록)
      return processedData.reverse(); // 데이터 반환
    } catch (err) {
      console.error("주식 데이터 가져오기 오류:", err);
      throw new Error("데이터 가져오기 실패");
    }
  }
  
  // 마지막 저장 날짜를 기록할 변수
let lastDate = null;

// 암호화폐 데이터 저장 함수
async function saveinfoData(stockData) {
    try {
        
             const stockDocument = new overView(stockData);
             await stockDocument.save();
        
        // 마지막 저장 날짜 업데이트
        lastDate = new Date().toISOString().split('T')[0]; // YYYY-MM-DD 형식
    } catch (err) {
        console.error("암호화폐 데이터 저장 오류:", err);
    }
}

  export async function overviewStockData(symbol) {
    try {
      const details = await yahooFinance.quote(symbol);

      const processedData = {
        symbol: details.symbol, // 주식 심볼
        name: details.shortName, // 주식 이름
        date: new Date().toISOString(), // 현재 날짜/시간
        type: details.quoteType || "Unknown",
        region: details.market || "Unknown",
        currency: details.currency || "USD",

        // 주식 정보
        marketPrice: details.regularMarketPrice, // 현재 주가
        marketChange: details.regularMarketChangePercent, // 주가 변동률
        marketCap: details.marketCap, // 시가총액
        trailingPE: details.trailingPE, // 주가수익비율 (P/E Ratio)
        eps: details.epsTrailingTwelveMonths, // 주당순이익 (EPS)
        dividendRate: details.dividendRate, // 배당금
        bookValue: details.bookValue, // 장부가치
        sharesOutstanding: details.sharesOutstanding, // 발행 주식 수
        bookValuePerShare: details.bookValue && details.sharesOutstanding
          ? (details.bookValue / details.sharesOutstanding).toFixed(2)
          : "N/A", // 장부가치 / 발행 주식 수

        // 주식 변동 및 거래 정보
        previousClose: details.regularMarketPreviousClose, // 전일 종가
        openPrice: details.regularMarketOpen, // 금일 시가
        dayRange: details.regularMarketDayRange
          ? `${details.regularMarketDayRange.low} - ${details.regularMarketDayRange.high}`
          : "N/A", // 금일 변동폭
        fiftyTwoWeekRange: details.fiftyTwoWeekRange
          ? `${details.fiftyTwoWeekRange.low} - ${details.fiftyTwoWeekRange.high}`
          : "N/A", // 52주 변동폭
        volume: details.regularMarketVolume, // 금일 거래량
        averageVolume: details.averageDailyVolume3Month, // 평균 거래량

        // 추가 정보
        earningsDate: details.earningsTimestampStart
        ? (() => {
        let timestamp = details.earningsTimestampStart;
        if (timestamp > 1000000000000) {  // 밀리초 단위라면 초 단위로 변환
            timestamp = Math.floor(timestamp / 1000);
        }
        return new Date(timestamp * 1000).toLocaleDateString("ko-KR", {
            year: "numeric",
            month: "long",
            day: "numeric"
        });
    })()
    : "N/A", // 다음 실적 발표일
      };
    
       // 성공적으로 저장된 데이터를 반환
      return processedData;
    } catch (error) {
      console.error(`Error processing stock ${symbol}:`, error);
      return null; // 실패한 경우 null 반환
    }
}

export async function overviewStock(symbol) {
  try {
    const apiKey = process.env.API_KEY;
    const response = await axios.get(
      `https://www.alphavantage.co/query`,
      {
        params: {
          function: "OVERVIEW",
          symbol: symbol,
          apikey: apiKey,
        },
      }
    );

    const stockData = response.data;

    if (!stockData || Object.keys(stockData).length === 0) {
      throw new Error("API 데이터가 없습니다.");
    }

    // 필요한 데이터만 추출
    const processedData = {
      date: new Date().toISOString(), // 현재 날짜 및 시간 추가
      symbol: stockData["Symbol"],
        assetType: stockData["AssetType"] || "Unknown",
        name: stockData["Name"] || "N/A",
        description: stockData["Description"] || "N/A",
        cik: stockData["CIK"] || "N/A",
        exchange: stockData["Exchange"] || "Unknown",
        currency: stockData["Currency"] || "USD",
        country: stockData["Country"] || "Unknown",
        sector: stockData["Sector"] || "Unknown",
        industry: stockData["Industry"] || "Unknown",
        address: stockData["Address"] || "N/A",
        officialSite: stockData["OfficialSite"] || "N/A",
        fiscalYearEnd: stockData["FiscalYearEnd"] || "N/A",
        latestQuarter: stockData["LatestQuarter"] || "N/A",
        marketCapitalization: stockData["MarketCapitalization"] || "N/A",
        ebitda: stockData["EBITDA"] || "N/A",
        peRatio: stockData["PERatio"] || "N/A",
        pegRatio: stockData["PEGRatio"] || "N/A",
        bookValue: stockData["BookValue"] || "N/A",
        dividendPerShare: stockData["DividendPerShare"] || "N/A",
        dividendYield: stockData["DividendYield"] || "N/A",
        eps: stockData["EPS"] || "N/A",
        revenuePerShareTTM: stockData["RevenuePerShareTTM"] || "N/A",
        profitMargin: stockData["ProfitMargin"] || "N/A",
        operatingMarginTTM: stockData["OperatingMarginTTM"] || "N/A",
        returnOnAssetsTTM: stockData["ReturnOnAssetsTTM"] || "N/A",
        returnOnEquityTTM: stockData["ReturnOnEquityTTM"] || "N/A",
        revenueTTM: stockData["RevenueTTM"] || "N/A",
        grossProfitTTM: stockData["GrossProfitTTM"] || "N/A",
        dilutedEPSTTM: stockData["DilutedEPSTTM"] || "N/A",
        quarterlyEarningsGrowthYOY: stockData["QuarterlyEarningsGrowthYOY"] || "N/A",
        quarterlyRevenueGrowthYOY: stockData["QuarterlyRevenueGrowthYOY"] || "N/A",
        analystTargetPrice: stockData["AnalystTargetPrice"] || "N/A",
        analystRatingStrongBuy: stockData["AnalystRatingStrongBuy"] || "N/A",
        analystRatingBuy: stockData["AnalystRatingBuy"] || "N/A",
        analystRatingHold: stockData["AnalystRatingHold"] || "N/A",
        analystRatingSell: stockData["AnalystRatingSell"] || "N/A",
        analystRatingStrongSell: stockData["AnalystRatingStrongSell"] || "N/A",
        trailingPE: stockData["TrailingPE"] || "N/A",
        forwardPE: stockData["ForwardPE"] || "N/A",
        priceToSalesRatioTTM: stockData["PriceToSalesRatioTTM"] || "N/A",
        priceToBookRatio: stockData["PriceToBookRatio"] || "N/A",
        evToRevenue: stockData["EVToRevenue"] || "N/A",
        evToEBITDA: stockData["EVToEBITDA"] || "N/A",
        beta: stockData["Beta"] || "N/A",
        fiftyTwoWeekHigh: stockData["52WeekHigh"] || "N/A",
        fiftyTwoWeekLow: stockData["52WeekLow"] || "N/A",
        fiftyDayMovingAverage: stockData["50DayMovingAverage"] || "N/A",
        twoHundredDayMovingAverage: stockData["200DayMovingAverage"] || "N/A",
        sharesOutstanding: stockData["SharesOutstanding"] || "N/A",
        dividendDate: stockData["DividendDate"] || "N/A",
        exDividendDate: stockData["ExDividendDate"] || "N/A",
    };

    // 데이터 저장 조건 확인
       // const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD 형식
       // if (lastDate !== today) {
       //     await saveinfoData(processedData);
       // } else {
       //     console.log("오늘은 이미 데이터가 저장되었습니다.");
       // }
    
    return processedData;
  } catch (err) {
    console.error("주식 데이터 가져오기 오류:", err);
    throw err; // 에러를 호출자로 전달
  }
}



 
