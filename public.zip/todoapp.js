import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

// __dirname 대체 변수 설정
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config();

const app=express();
const port = process.env.port || 3000;

//뷰 엔진 설정
app.set("view engine","ejs");
app.set("views",path.join(__dirname, "views")); //경로설정
// 정적 파일 제공
app.use(express.static(path.join(__dirname, "public")));

// MongoDB 연결
mongoose
  .connect("mongodb://127.0.0.1:27017/tododb", { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB 연결 성공"))
  .catch((err) => console.error("MongoDB 연결 실패", err));

  // 할 일 스키마 정의
const todoSchema = new mongoose.Schema({
    task: String,
    completed: Boolean,
  });
  
  // 할 일 모델 생성
  const Todo = mongoose.model("Todo", todoSchema);

  //라우트: 메인 페이지(뷰 랜더링)
  app.get("/",async (req,res)=>{
    try {
        const todos = await Todo.find();
        res.render("main", { todos }); // EJS 템플릿에 할 일 데이터를 전달
      } catch (err) {
        console.error("할 일 조회 실패:", err);
        res.status(500).send("서버 오류");
      }
  });

  app.post("/add",async (req, res) => {
    try {
      const newTodo = new Todo({
        task: "Learn MongoDB",
        completed: false,
      });
      await newTodo.save();
      res.redirect("/"); // 추가 후 메인 페이지로 리디렉션
    } catch (err) {
      console.error("할 일 추가 실패:", err);
      res.status(500).send("서버 오류");
    }
  });

  app.listen(port,()=>{
    console.log(`서버가 http://localhost:${port} 에서 실행 중입니다.`);
  });