import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    // 개발 서버 설정
    port: 5173, // React 개발 서버 포트
    proxy: {
      // 프록시 설정: 백엔드와 통신하기 위한 경로
      '/react': {
        target: 'http://localhost:9088/bugHunters_TMI', // Spring Boot 서버 주소
        changeOrigin: true, // 출처(origin)를 백엔드로 변경
        secure: false, // HTTPS가 아닌 HTTP를 허용
      },
    },
  },
})
