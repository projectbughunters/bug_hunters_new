import { Link, Route, Routes, useNavigate } from "react-router-dom";
import BoardInfo from "../components/boardComponents/BoardInfo";
import NoticeInput from "../components/boardComponents/NoticeInput";
import CommentManagement from "../components/boardComponents/CommentManagement";
import NoticeUpdate from "../components/boardComponents/NoticeUpdate";
import BoardDetail from "../components/boardComponents/BoardDetail";
import NoticeList from "../components/boardComponents/NoticeList";
import FinancialManagement from "../components/financialComponents/Financialmanagement";
import MainImg from "../components/MainImg";
import "./Management.css";

const Management = () => {
    const navigate = useNavigate();

    return (
        <div className="body">
            <div className="header">
                <div className="link-container">
                    <div className="all-container">
                        <div className="button-container" id="logo-container">
                            <div onClick={() => navigate("/")}>
                                <img className="logo" src="/img/TMI_YB.png" alt="TMI Logo" />
                            </div>
                        </div>
                        <div className="contents-container">
                            {/* 게시글 관리 드롭다운 */}
                            <div className="dropdown-container">
                                <div className="button-container">
                                    <button>게시글 관리</button>
                                </div>
                                <div className="dropdown-menu">
                                    <Link to="/info-management" className="dropdown-link">
                                        <button>게시글 목록</button>
                                    </Link>
                                    <Link to="/notice-input" className="dropdown-link">
                                        <button>공지사항 입력</button>
                                    </Link>
                                    <Link to="/notice-list" className="dropdown-link">
                                        <button>공지사항 수정</button>
                                    </Link>
                                </div>
                            </div>
                            <div className="button-container">
                                <Link to="/financial-management">
                                    <button>재무제표 관리</button>
                                </Link>
                            </div>
                        </div>
                        <div className="go-home">
                            <Link to="http://localhost:9088/bugHunters_TMI/">
                                <button>홈페이지</button>
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
            <div className="primary-container">
                <Routes>
                    <Route path="/" element={<MainImg />} />
                    <Route path="info-management" element={<BoardInfo />} />
                    <Route path="info-management/detail/:boardIdx" element={<BoardDetail />} />
                    <Route path="notice-input" element={<NoticeInput />} />
                    <Route path="notice-list" element={<NoticeList />} />
                    <Route path="notice-list/notice-update/:noticeIdx" element={<NoticeUpdate />} />
                    <Route path="info-management/detail/:boardIdx" element={<CommentManagement />} />
                    <Route path="update" element={<NoticeUpdate />} />
                    <Route path="financial-management" element={<FinancialManagement />} />
                </Routes>
            </div>
        </div>
    );
};

export default Management;
