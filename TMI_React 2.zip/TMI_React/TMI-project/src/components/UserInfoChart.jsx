import React, { useEffect, useRef, useState } from "react";
import { Bar } from 'react-chartjs-2';
import Chart from 'chart.js/auto';
import "./UserInfoChart.css";

const UserInfoChart = () => {
    const chartRef1 = useRef(null);
    const chartRef2 = useRef(null);
    const [isVisible, setIsVisible] = useState(false); // 애니메이션 상태

    const data1 = {
        labels: ['사이트 사용자 수', '포트폴리오 생성 사용자 수'],
        datasets: [
            {
                label: '사용자 수',
                backgroundColor: ['rgb(82, 106, 248)', 'rgb(75, 112, 186)'],
                borderColor: 'rgba(0,0,0,1)',
                borderWidth: 0,
                data: [300, 150],
                barThickness: 60,
            },
        ],
    };

    const options1 = {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: true,
                position: 'top',
            },
            tooltip: {
                enabled: true,
            },
        },
        scales: {
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: '사용자 수',
                },
                grid: {
                    display: false,
                },
            },
            x: {
                title: {
                    display: true,
                    text: '사용자 유형',
                },
                grid: {
                    display: false,
                },
            },
        },
    };

    const data2 = {
        labels: ['주식 데이터 생성 수', '코인 데이터 생성 수'],
        datasets: [
            {
                label: '데이터 수',
                backgroundColor: ['rgb(176, 130, 240)', 'rgb(123, 102, 241)'],
                borderColor: 'rgba(0,0,0,1)',
                borderWidth: 0,
                data: [200, 500],
                barThickness: 60,
            },
        ],
    };

    const options2 = {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: true,
                position: 'top',
            },
            tooltip: {
                enabled: true,
            },
        },
        scales: {
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: '데이터 수',
                },
                grid: {
                    display: false,
                },
            },
            x: {
                title: {
                    display: true,
                    text: '데이터 유형',
                },
                grid: {
                    display: false,
                },
            },
        },
    };

    // 첫 번째 차트 생성 및 정리
    useEffect(() => {
        const chartInstance1 = new Chart(chartRef1.current, {
            type: 'bar',
            data: data1,
            options: options1,
        });

        return () => {
            chartInstance1.destroy();
        };
    }, [data1]);

    // 두 번째 차트 생성 및 정리
    useEffect(() => {
        const chartInstance2 = new Chart(chartRef2.current, {
            type: 'bar',
            data: data2,
            options: options2,
        });

        return () => {
            chartInstance2.destroy();
        };
    }, [data2]);

    // Intersection Observer 설정
    useEffect(() => {
        const observer = new IntersectionObserver(([entry]) => {
            if (entry.isIntersecting) {
                setIsVisible(true); // 요소가 보일 때 상태 업데이트
                observer.disconnect(); // 더 이상 관찰하지 않음
            }
        });

        if (chartRef1.current) {
            observer.observe(chartRef1.current.parentElement); // 부모 요소를 관찰
        }

        return () => {
            observer.disconnect(); // 컴포넌트 언마운트 시 관찰 중지
        };
    }, []);

    return (
        <div className={`chart-container ${isVisible ? 'fade-in' : ''}`} style={{ width: '100%', height: '400px' }}>
            <div className="chart1">
                <h2>사용자 수</h2>
                <canvas ref={chartRef1} style={{ width: '50%', height: '300px' }} />
            </div>
            <div className="chart2">
                <h2>데이터 생성량</h2>
                <canvas ref={chartRef2} style={{ width: '50%', height: '300px' }} />
            </div>
        </div>
    );
};

export default UserInfoChart;
