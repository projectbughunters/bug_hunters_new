import { useEffect, useState } from "react";
import styled from 'styled-components';

const ImageContainer = styled.div`
    width: 100%; /* 원하는 너비 */
    overflow: hidden; /* 이미지가 div를 넘어갈 경우 숨김 */
    position: relative; /* 자식 요소의 위치 설정 */
`;

const ResponsiveImage = styled.img`
    width: 100%; /* div의 너비에 맞게 설정 */
    height: auto; /* 자동 높이 설정 */
    object-fit: cover; /* 비율을 유지하며 이미지가 div를 꽉 차게 설정 */
`;

const MainImg = () => {
    const [imageUrl, setImageUrl] = useState("");

    useEffect(() => {
        // 이미지 URL을 설정합니다.
        setImageUrl("/img/adminMain3.png"); // 실제 이미지 경로로 변경하세요.
    }, []);

    return (
        <ImageContainer>
            {imageUrl && (
                <ResponsiveImage src={imageUrl} alt="Main visual" />
            )}
        </ImageContainer>
    );
};

export default MainImg;
