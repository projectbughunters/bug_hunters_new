// src/pages/FinancialManagement.jsx
import axios from "axios";
import {useState} from "react";
import "./FinancialManagement.css";

const FinancialManagement = () => {

    // 필요한 필드만 분리해서 관리할 수도 있고 기존 formData에 포함시켜도 됩니다.
    const [symbol, setSymbol] = useState("");
    // 자동 업데이트하기용 심볼 상태
    const [updateSymbol, setUpdateSymbol] = useState("");

    // input 값 변경 핸들러 (업데이트 시)
    const handleUpdateChange = (e) => {
        setUpdateSymbol(e.target.value);
    };

    // 심볼 입력값 변경
    const handleSymbolChange = (e) => {
        setSymbol(e.target.value);
    };

    // 데이터 저장 폼 제출 시, 심볼을 포함한 API 요청
    const handleSaveSubmit = async (e) => {
        e.preventDefault();
        try {
            // 입력한 symbol 값을 API 요청과 함께 전달함
            await axios.put("/react/datasave", {symbol: symbol});
            alert("데이터가 성공적으로 저장되었습니다!");
        } catch (error) {
            console.error(error);
            alert("저장 중 오류가 발생했습니다.");
        }
    };
    const handleUpdateSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.put("/react/dataupdate", {symbol: symbol});
            alert("데이터가 성공적으로 업데이트되었습니다!")
        } catch (error) {
            console.error(error);
            alert("데이터 업데이트 중 오류가 발생했습니다.");
        }
    };

    return (
        <div className="financial-management">
            <h2 className="title">재무제표 관리</h2>
            <form onSubmit={handleSaveSubmit} className="eco-form">
                {/* 심볼을 입력할 수 있는 텍스트 박스를 추가 */}
                <input
                    type="text"
                    name="symbol"
                    placeholder="Symbol 입력"
                    value={symbol}
                    onChange={handleSymbolChange}
                    required
                />
                <button type="submit" className="form-button">재무제표 저장</button>
            </form>
            {/* 자동 업데이트하기 폼 */}
            <form onSubmit={handleUpdateSubmit} className="eco-form">
                <input
                    type="text"
                    name="symbol"
                    placeholder="Symbol 입력"
                    value={updateSymbol}
                    onChange={handleUpdateChange}
                    required
                />
                <button type="submit" className="form-button">재무제표 업데이트</button>
            </form>
        </div>
    );
};

export default FinancialManagement;
