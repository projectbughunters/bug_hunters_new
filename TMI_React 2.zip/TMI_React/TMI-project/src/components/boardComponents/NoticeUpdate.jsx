import axios from "axios";
import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom"; // useParams import 추가
import "./NoticeUpdate.css";

const NoticeUpdate = () => {
    const { noticeIdx } = useParams(); // URL에서 noticeIdx 가져오기
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [writeDate, setWriteDate] = useState(''); // 작성 시간 상태 추가
    const [viewCount, setViewCount] = useState(0); // 조회수 상태 추가
    const [likeCount, setLikeCount] = useState(0); // 추천 수 상태 추가
    const [message, setMessage] = useState('');
    const navigate = useNavigate(); // navigate 함수를 사용하여 페이지 이동

    useEffect(() => {
        // 공지사항 데이터를 가져오는 함수
        const fetchNotice = async () => {
            try {
                const response = await axios.post('/react/noticeInfo', { board_idx: noticeIdx });
                const { title, content, write_date, view_count, like_count } = response.data; // API 응답에서 추가 정보 추출
                setTitle(title);
                setContent(content);
                setWriteDate(write_date); // 작성 시간 설정
                setViewCount(view_count); // 조회수 설정
                setLikeCount(like_count); // 추천 수 설정
            } catch (error) {
                console.error("공지사항을 가져오는 중 오류가 발생했습니다:", error);
                setMessage('공지사항을 가져오는 중 오류가 발생했습니다.');
            }
        };

        fetchNotice(); // 컴포넌트가 마운트될 때 공지사항 데이터 가져오기
    }, [noticeIdx]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.put('/react/noticeUpdate', {
                title,
                content,
                write_date: new Date().toISOString().slice(0, 19).replace('T', ' '), // 현재 날짜와 시간
                view_count: viewCount, // 조회수
                like_count: likeCount, // 추천 수
                board_idx: noticeIdx, // 게시글 ID 
                content_file: null, //사용하지 않음
                type: '공지사항',
                complain_category: null //사용하지 않음
            });
            setMessage('공지사항이 성공적으로 수정되었습니다!');
            setTimeout(() => {
                setMessage('');
            }, 3000);
        } catch (error) {
            console.error("수정 중 오류가 발생했습니다:", error);
            setMessage('수정 중 오류가 발생했습니다.');
        }
    };

    // 삭제 함수
    const deleteNotice = async () => {
        try {
            // noticeIdx가 유효한지 확인
            if (!noticeIdx) {
                throw new Error("Invalid notice_idx.");
            }
            console.log("noticeIdx", noticeIdx);
            await axios.delete(`/react/boardDelete?board_idx=${noticeIdx}`);
            setMessage('공지사항이 삭제되었습니다.');
            setTimeout(() => {
                navigate(-1); // 삭제 후 게시판 목록으로 이동
            }, 2000);
        } catch (error) {
            console.error("공지사항 삭제 중 오류가 발생했습니다:", error);
            setMessage('공지사항 삭제 중 오류가 발생했습니다.');
        }
    };



    return (
        <div className="notice-update-container" style={{ padding: "20px" }}>
            <h2>공지사항 수정</h2>
            <form id="update-form" onSubmit={handleSubmit}>
                <div>
                    <label>제목:</label>
                    <input
                        type="text"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        required
                        maxLength={20} // 최대 글자 수를 20으로 설정 
                    />
                </div>
                <div className="notice-content">
                    <label>내용:</label>
                    <textarea
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                        required
                        maxLength={1300} // 최대 글자 수를 1300으로 설정
                    />
                </div>
                <div className="notice-info">
                    <label>작성 시간:</label>
                    <input
                        type="text"
                        value={writeDate}
                        readOnly // 읽기 전용으로 설정
                    />
                </div>
                <div className="notice-info">
                    <label >조회수:</label>
                    <input
                        type="number"
                        value={viewCount}
                        readOnly // 읽기 전용으로 설정
                    />
                </div>
                <div className="notice-info">
                    <label>추천 수:</label>
                    <input
                        type="number"
                        value={likeCount}
                        readOnly // 읽기 전용으로 설정
                    />
                </div>
                <div id="update-btn">
                <button type="submit">수정</button>
                <button type="button" onClick={deleteNotice}>삭제</button>
                </div>
                {message && <p className="message">{message}</p>}
            </form>
        </div>
    );
};

export default NoticeUpdate;
