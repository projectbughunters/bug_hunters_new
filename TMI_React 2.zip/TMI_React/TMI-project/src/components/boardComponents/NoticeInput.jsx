import axios from "axios";
import { useEffect, useState } from "react";
import "./NoticeInput.css";

const NoticeInput = () => {
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [message, setMessage] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('/react/noticeInput', {
                title,
                content,
                write_date: new Date().toISOString().slice(0, 19).replace('T', ' '), // 'YYYY-MM-DD HH:MM:SS' 형식으로 변환
                member_idx: 10000, 
                type: '공지게시판', //공지게시판으로 타입 고정
                complain_category: null,
                notice_code:"none"
            });
            setMessage('공지사항이 등록되었습니다.');
            setTitle('');
            setContent('');
            
            setTimeout(() => {
                setMessage('');
            }, 3000);

        } catch (error) {
            
            console.error("데이터를 삽입하는 중 오류가 발생했습니다:", error);
            setMessage('오류가 발생했습니다. 다시 시도해 주세요.');
        }
    };

    return (
        <div className="notice-input-container">
            <h2>공지사항 등록</h2>
            <form id="input-form" onSubmit={handleSubmit}>
                <div>
                    <label>제목:</label>
                    <input 
                        type="text" 
                        value={title} 
                        onChange={(e) => setTitle(e.target.value)} 
                        required 
                    />
                </div>
                <div>
                    <label>내용:</label>
                    <textarea 
                        value={content} 
                        onChange={(e) => setContent(e.target.value)} 
                        required 
                    />
                </div>
                <div id="input-btn">
                <button type="submit">등록</button>
                </div>
                {message && <p className="message">{message}</p>}

            </form>
        </div>
    );
};

export default NoticeInput;
