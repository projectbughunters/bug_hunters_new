import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import "./Boarddetail.css";
import CommentManagement from "./CommentManagement";

const BoardDetail = () => {
    const { boardIdx } = useParams(); // URL에서 boardIdx 추출
    const [boardDetail, setBoardDetail] = useState(null); // 게시글 상세 정보를 저장할 상태
    const [loading, setLoading] = useState(true); // 로딩 상태
    const [message, setMessage] = useState(''); // 사용자 피드백 메시지 상태
    const navigate = useNavigate(); // navigate 함수를 사용하여 페이지 이동

    useEffect(() => {
        const fetchBoardDetail = async () => {
            try {
                const response = await axios.get('/react/boardDetail', {
                    params: { board_idx: boardIdx } // boardIdx를 쿼리 파라미터로 전달
                });
                setBoardDetail(response.data); // 가져온 게시글 상세 정보를 상태에 저장
                setLoading(false); // 로딩 완료
            } catch (error) {
                console.error("게시글을 가져오는 중 오류가 발생했습니다:", error);
                setLoading(false); // 로딩 완료
            }
        };
        fetchBoardDetail();
    }, [boardIdx]);

    // 삭제 함수
    const deleteBoard = async (boardIdx) => {
        try {
            // boardIdx가 올바르게 전달되는지 확인
            if (typeof boardIdx !== 'number') {
                throw new Error("Invalid board_idx.");
            }
            console.log("boardIdx",boardIdx);
            await axios.delete(`/react/boardDelete?board_idx=${boardIdx}`);
            setMessage('게시글이 삭제되었습니다.');
            setTimeout(() => {
                navigate(-1); // 삭제 후 게시판 목록으로 이동
            }, 2000);
        } catch (error) {
            console.error("게시글 삭제 중 오류가 발생했습니다:", error);
            setMessage('게시글 삭제 중 오류가 발생했습니다.');
        }
    };

    if (loading) {
        return <div>Loading...</div>; // 로딩 중 표시
    }

    if (!boardDetail) {
        return <div>게시글을 찾을 수 없습니다.</div>; // 게시글이 없을 경우
    }

    return (
        <div className="board-detail">
            <button onClick={() => deleteBoard(boardDetail.board_idx)}>삭제</button>
            <h2 className="board-title">{boardDetail.title}</h2>
            <div className="board-info-container">
                <div className="board-info">
                    <p><strong>작성자 ID :</strong> {boardDetail.member_id}</p>
                    <p><strong>작성시간 :</strong> {boardDetail.write_date}</p>
                </div>
                <div className="board-info">
                    <p><strong>조회수 :</strong> {boardDetail.view_count}</p>
                    <p><strong>추천 수 :</strong> {boardDetail.like_count}</p>
                </div>
            </div>
            <div className="board-content">
                <h3>내용</h3>
                <div id="board-box">
                    <p>{boardDetail.content}</p>
                </div>
            </div>
            <div>
                <CommentManagement />
            </div>
        </div>
    );
};

export default BoardDetail;
