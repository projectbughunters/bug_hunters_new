import axios from "axios";
import { useEffect, useState } from "react";
import "./NoticeList.css"; // 스타일을 위한 CSS 파일 import
import { Link } from "react-router-dom";

// 공지사항 게시판 읽어오는 함수
const NoticeList = () => {
    const [notices, setNotices] = useState([]);
    const [message, setMessage] = useState('');
    const [selectedNotices, setSelectedNotices] = useState(new Map()); // 선택된 공지사항을 관리하는 상태

    // 공지사항 목록을 가져오는 함수
    const fetchNotices = async () => {
        try {
            const response = await axios.get('/react/boardInfo');
            const filteredNotices = response.data.filter(notice => notice.type === "공지게시판");
            setNotices(filteredNotices);
        } catch (error) {
            console.error("공지사항 목록을 가져오는 중 오류가 발생했습니다:", error);
            setMessage('공지사항 목록을 가져오는 중 오류가 발생했습니다.');
        }
    };

    useEffect(() => {
        fetchNotices(); // 컴포넌트가 마운트될 때 공지사항 목록 가져오기
    }, []);

    // 버튼 클릭 처리 함수
    const handleButtonClick = async (boardIdx, status) => {
        try {
            // 선택된 공지사항의 상태 업데이트
            await axios.put('/react/updateNoticeCode', {
                notice_code: status,
                board_idx: boardIdx
            });

            // 선택된 공지사항 상태를 업데이트
            setSelectedNotices(prev => new Map(prev).set(boardIdx, status));

            // 목록 새로고침
            await fetchNotices();
            
            setTimeout(() => {
                setMessage('');
            }, 3000);
        } catch (error) {
            console.error("공지사항 코드 업데이트 중 오류가 발생했습니다:", error);
            setMessage('공지사항 코드 업데이트 중 오류가 발생했습니다.');
        }
    };

    return (
        <div className="noticelists-all">
            <h2>공지사항 목록</h2>
            {message && <p className="message">{message}</p>}
            <div className="noticelists-container">
            <table className="noticelists-table">
                <thead>
                    <tr>
                        <th style={{width: '110px'}}>공지상단등록</th>
                        <th style={{width: '40px'}}>번호</th>
                        <th>제목</th>
                        <th>내용</th>
                        <th style={{width: '120px'}}>작성일</th>
                    </tr>
                </thead>
                <tbody>
                    {notices.length > 0 ? (
                        notices.map((notice) => (
                            <tr key={notice.board_idx}>
                                <td>
                                    <button
                                        onClick={() => handleButtonClick(notice.board_idx, "notice")} // "공지띄우기" 클릭 시 처리
                                        style={{ backgroundColor: notice.notice_code === "notice" ? 'blue' : 'lightgrey' }}
                                    >
                                        등록
                                    </button>
                                
                                    <button
                                        onClick={() => handleButtonClick(notice.board_idx, "none")} // "공지 내리기" 클릭 시 처리
                                        style={{ backgroundColor: notice.notice_code === "none" ? 'red' : 'lightgrey' }}
                                    >
                                        해제
                                    </button>
                                </td>
                                <td id="notice-num">{notice.board_idx}</td>
                                <td>
                                    <Link to={`/notice-list/notice-update/${notice.board_idx}`}>
                                        {notice.title}
                                    </Link>
                                </td>
                                <td id="notice-content">{notice.content}</td>
                                <td>{notice.write_date}</td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan="5">등록된 공지사항이 없습니다.</td>
                        </tr>
                    )}
                </tbody>
            </table>
            </div>
        </div>
    );
};

export default NoticeList;
