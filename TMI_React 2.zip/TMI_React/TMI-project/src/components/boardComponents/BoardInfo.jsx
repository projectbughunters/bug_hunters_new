import axios from "axios";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom"; // Link 컴포넌트 임포트
import "./boardinfo.css";

const BoardInfo = () => {
    const [boardInfo, setBoardInfo] = useState([]);

    useEffect(() => {
        const fetchBoardInfo = async () => {
            try {
                const response = await axios.get('/react/boardInfo'); // Spring 서버 주소
                setBoardInfo(response.data); // 가져온 데이터를 상태에 저장
            } catch (error) {
                console.error("데이터를 가져오는 중 오류가 발생했습니다:", error);
            }
        };

        fetchBoardInfo();
    }, []);

    return (
        
        <div className="board-container">
            <h2>게시글 목록</h2>
            <div className="table-container">
                <table className="info-table">
                    <thead>
                        <tr>
                            <th style={{width:'100px'}}>게시글 번호</th>
                            <th>제목</th>
                            <th>작성자 ID</th>
                            <th>내용</th>
                            <th style={{width:'60px'}}>조회수</th>
                            <th style={{width:'60px'}}>추천 수</th>
                            <th style={{width:'150px'}}>작성시간</th>
                        </tr>
                    </thead>
                    <tbody>
                        {boardInfo.map((info, index) => (
                            <tr key={index}>
                                <td id="board-num">{info.board_idx}</td>
                                <td id="board-title">
                                    <Link to={`/info-management/detail/${info.board_idx}`}> {/* 제목 클릭 시 게시글 상세로 이동 */}
                                        {info.title}
                                    </Link>
                                </td>
                                <td>{info.member_id}</td>
                                <td id="board-contents">{info.content}</td>
                                <td>{info.view_count}</td>
                                <td>{info.like_count}</td>
                                <td>{info.write_date}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default BoardInfo;
