import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const CommentManagement = () => {
    const [comments, setComments] = useState([]);
    const [message, setMessage] = useState('');
    const {boardIdx}  = useParams(); // URL에서 boardIdx 추출

    // 댓글 목록 가져오기
    useEffect(() => {
        const fetchComments = async () => {
            try {
                const response = await axios.get('/react/getComments', {
                    params: {
                        board_idx: boardIdx // boardIdx를 쿼리 파라미터로 전달
                    }
                });
                setComments(response.data);
            } catch (error) {
                console.error("댓글을 가져오는 중 오류가 발생했습니다:", error);
                setMessage('댓글을 가져오는 중 오류가 발생했습니다.');
            }
        };

        fetchComments();
    }, [boardIdx]);


    // 댓글 삭제
    const commentDelete = async (commentIdx) => {
        try {
            await axios.delete(`/react/commentDelete?comment_idx=${commentIdx}`);
            setComments(comments.filter(comment => comment.comment_idx !== commentIdx)); // 삭제 후 목록 갱신
            setMessage('댓글이 삭제되었습니다.');
        } catch (error) {
            console.error("댓글을 삭제하는 중 오류가 발생했습니다:", error);
            setMessage('오류가 발생했습니다. 다시 시도해 주세요.');
        }
    };

    return (
        <div>
            <h4>댓글 목록</h4>
            {message && <p>{message}</p>}
            <ul>    
                {comments.map((comment) => (
                    <li key={comment.comment_idx}>
                       <p style={{ fontWeight: 'bold' }}>{comment.member_id}</p>
                        <p>{comment.comment_content}</p>
                        <p>작성 시간: {new Date(comment.comment_time).toLocaleString()}</p>
                        <button onClick={() => commentDelete(comment.comment_idx)}>삭제</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default CommentManagement;
