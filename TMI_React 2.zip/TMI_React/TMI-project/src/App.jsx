import "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Management from "./pages/Management.jsx";

function App() {
  return (
      <Router>
        <Routes>
          <Route path="/*" element={<Management />} />
        </Routes>
      </Router>
  );
}

export default App;